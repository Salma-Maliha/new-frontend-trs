import { useState } from 'react';

const Home = () => {
  const [formData, setFormData] = useState({
    stitchType: '',
    stitchDescription: '',
    seamLength: '',
    stitchRow: '',
    numberOfLayer: '',
    SPI: '',  
    threadName_Type: '', // New state variable for Thread Name/Thread Type
    fabricThickness: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    let description = '';
    let spi = '';

    if (value === '101') {
      description = 'Single thread chainstitch';
    } else if (value === '103') {
      description = 'Single thread blindstitch';
    } else if (value === '301') {
      description = 'Lockstitch';
      spi = '16';  
    } else if (value === '304') {
      description = 'Lockstitch (zig-zag)';
    } else if (value === '401') {
      description = 'Double chainstitch';
    } else if (value === '406') {
      description = '2-needle cover chainstitch';
    } else if (value === '407') {
      description = '3-needle Bottom coverstitch';
    } else if (value === '408') {
      description = '2 times double chainstitch';
    } else if (value === '503') {
      description = '2-thread overlock stitch';
    } else if (value === '504') {
      description = '3-thread overlock stitch';
    } else if (value === '514') {
      description = '4-thread overlock stitch';
    } else if (value === '516') {
      description = 'Safety Stitch';
    } else if (value === '602') {
      description = 'double NDL coverstitch';
    } else if (value === '605') {
      description = '3-needle cover chainstitch';
    } else if (value === '607') {
      description = '4-needle cover chainstitch';
    } else if (value === 'Bartack') {
      description = 'Bartack';
    } else if (value === 'Button_Hole') {
      description = 'Button_Hole';
    } else if (value === 'Button_Sew') {
      description = 'Button Attach';
    }

    setFormData({
      ...formData,
      [name]: value,
      stitchDescription: description,
      SPI: spi 
    });
  };

  const handleAddButton = () => {
    console.log(formData); // Log the form data when Add button is clicked
  };

  return (
    <div className="p-4">
      <form className="grid grid-cols-2 gap-4">
        {/* Your form fields */}
        {/* Example for one field */}
        <div className="flex flex-col">
          <label htmlFor="stitchType" className="text-sm">Stitch Type:</label>
          <select 
            id="stitchType" 
            name="stitchType" 
            value={formData.stitchType} 
            onChange={handleChange} 
            className="mt-1 p-2 border rounded-md"
          >
            <option value="">-- Select Stitch Type --</option>
            {/* Add other options */}
          </select>
        </div>
        {/* Add button */}
        <div className="flex flex-col">
          <button onClick={handleAddButton} className="mt-1 p-2 border rounded-md bg-blue-500 text-white">Add</button>
        </div>
      </form>
    </div>
  );
}

export default Home;
